# boilerplate

A production-ready Go HTTP server boilerplate with structured logging, OpenTelemetry, graceful shutdown, and code-first OpenAPI/Swagger docs. Includes a sample CRUD API for `/items`.

## Features

- **HTTP server** — [chi](https://github.com/go-chi/chi) router with request ID, real IP, and panic recovery middleware
- **Structured logging** — `log/slog` JSON handler with configurable level
- **Distributed tracing** — OpenTelemetry traces (stdout in dev, OTLP HTTP in production)
- **Metrics** — OpenTelemetry metrics with a per-operation counter on the items service
- **Graceful shutdown** — signal-aware shutdown with configurable drain timeout
- **In-memory store** — thread-safe store behind a `ItemStore` interface (swap in a real DB adapter without touching service or handler code)
- **OpenAPI / Swagger** — code-first spec generated from handler annotations via [swaggo/swag](https://github.com/swaggo/swag); interactive UI served at `/docs/`
- **Health check** — `GET /health`

## Project structure

```
.
├── cmd/server/main.go              # Entry point (swag metadata comment lives here)
├── docs/                           # Generated — do not edit (regenerate with make swagger)
│   ├── docs.go
│   ├── swagger.json
│   └── swagger.yaml
├── internal/
│   ├── config/config.go            # Environment-based configuration
│   ├── telemetry/telemetry.go      # OTel trace + metric provider setup
│   ├── middleware/middleware.go     # Logger and Recovery middleware
│   ├── model/                      # Domain types and sentinel errors
│   ├── store/                      # ItemStore interface + in-memory impl (+ tests)
│   ├── service/                    # Business logic with tracing and metrics (+ tests)
│   └── api/
│       ├── routes.go               # Router wiring + Swagger UI mount
│       ├── items.go                # CRUD handlers with swag annotations
│       ├── items_test.go           # httptest handler tests
│       └── response.go             # JSON response helpers
├── .github/workflows/ci.yml        # CI: build, test, golangci-lint
├── .golangci.yml                   # golangci-lint v2 configuration
├── .pre-commit-config.yaml         # Pre-commit hooks (fmt, lint, gitleaks, hadolint, ...)
├── .env.example                    # Documented environment variables
├── Dockerfile                      # Multi-stage build → distroless image
├── LICENSE                         # Apache 2.0
└── Makefile
```

## Getting started

```bash
# Run in development (traces printed to stdout)
make run

# Open the Swagger UI
open http://localhost:8080/docs/

# Build binary
make build
./bin/server

# Run with OTLP export (e.g. local Jaeger / OTel Collector)
OTLP_ENDPOINT=localhost:4318 ./bin/server
```

## Swagger / OpenAPI

The spec is generated from Go comment annotations via `swaggo/swag`. Run `make swagger` after editing any handler to regenerate.

| Artifact | Path |
|---|---|
| Interactive UI | `http://localhost:8080/docs/` |
| Raw JSON spec | `http://localhost:8080/docs/doc.json` |
| JSON file | `docs/swagger.json` |
| YAML file | `docs/swagger.yaml` |

**Never edit files under `docs/` by hand** — they are overwritten by `make swagger`.

When adding a new handler, include a swag annotation block above the function:

```go
// create godoc
//
// @Summary      Create an item
// @Description  Creates a new item and returns it.
// @Tags         items
// @Accept       json
// @Produce      json
// @Param        item  body      model.CreateItemRequest  true  "Item payload"
// @Success      201   {object}  model.Item
// @Failure      400   {object}  errorBody
// @Router       /items [post]
func (h *itemHandler) create(w http.ResponseWriter, r *http.Request) { ... }
```

Then run:

```bash
make swagger
```

## Environment variables

| Variable          | Default       | Description                                      |
|-------------------|---------------|--------------------------------------------------|
| `PORT`            | `8080`        | Listen port                                      |
| `LOG_LEVEL`       | `info`        | `debug` / `info` / `warn` / `error`             |
| `SERVICE_NAME`    | `boilerplate` | OTel resource service name                       |
| `SERVICE_VERSION` | `0.1.0`       | OTel resource service version                    |
| `OTLP_ENDPOINT`   | *(empty)*     | OTLP HTTP endpoint — omit to use stdout exporter |

## API

### Health

```
GET /health
```

```json
{"status":"ok","time":"2026-05-25T16:00:00Z"}
```

### Items CRUD

| Method   | Path         | Description        | Success |
|----------|--------------|--------------------|---------|
| `GET`    | `/items`     | List all items     | 200     |
| `POST`   | `/items`     | Create an item     | 201     |
| `GET`    | `/items/:id` | Get item by ID     | 200     |
| `PUT`    | `/items/:id` | Replace an item    | 200     |
| `DELETE` | `/items/:id` | Delete an item     | 204     |

**Create / update request body:**

```json
{
  "name": "Widget",
  "description": "A fine widget"
}
```

**Item response:**

```json
{
  "id": "93b33649-8d10-4ca2-aeb6-8b4dc7fb37e7",
  "name": "Widget",
  "description": "A fine widget",
  "created_at": "2026-05-25T16:00:00Z",
  "updated_at": "2026-05-25T16:00:00Z"
}
```

**Error response:**

```json
{
  "code": "not_found",
  "message": "item not found"
}
```

## Replacing the in-memory store

Implement `store.ItemStore` and pass it to `service.NewItemService`:

```go
type ItemStore interface {
    List(ctx context.Context) ([]*model.Item, error)
    Get(ctx context.Context, id string) (*model.Item, error)
    Create(ctx context.Context, item *model.Item) error
    Update(ctx context.Context, item *model.Item) error
    Delete(ctx context.Context, id string) error
}
```

## Testing

```bash
make test     # go test ./... -v -race -count=1
make cover    # write coverage.out + coverage.html
```

The `ItemStore` interface and injected telemetry handles keep the store, service, and API
layers unit-testable; see the `*_test.go` files for table-driven and `httptest` examples.

## Docker

A multi-stage `Dockerfile` builds a static binary into a `distroless` non-root image.

```bash
make docker                              # docker build -t boilerplate .
docker run -p 8080:8080 boilerplate
```

## Continuous integration

`.github/workflows/ci.yml` runs on every push and pull request: `go build`,
`go test ./... -race`, and `golangci-lint`.

## Pre-commit Hooks

This project ships a `.pre-commit-config.yaml` (Go formatting/build, `go vet`, `golangci-lint`,
`gitleaks` secret scanning, `hadolint` for the Dockerfile, and Conventional Commit messages).
Enable the hooks in your local clone with [Homebrew](https://brew.sh):

```bash
brew install pre-commit
pre-commit install                         # wires the pre-commit (git) hook
pre-commit install --hook-type commit-msg  # enable Conventional Commit checking
pre-commit run --all-files                 # run everything once
```

Hooks then run automatically on `git commit`. Go and Docker should be installed; pre-commit
manages the rest. You can also run them on demand with `make precommit`.

## License

Licensed under the Apache License 2.0. See [LICENSE](LICENSE).

## Makefile targets

```bash
make build      # Compile to bin/server
make run        # go run ./cmd/server
make test       # go test ./... -v -race
make cover      # Coverage report (coverage.html)
make fmt        # gofmt -w .
make vet        # go vet ./...
make swagger    # Regenerate docs/ from handler annotations
make tidy       # go mod tidy
make lint       # golangci-lint run ./...
make docker     # docker build -t boilerplate .
make precommit  # pre-commit run --all-files
```
