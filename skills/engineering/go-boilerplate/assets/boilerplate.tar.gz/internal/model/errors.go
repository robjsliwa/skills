package model

import "errors"

var (
	ErrNotFound     = errors.New("not found")
	ErrNameRequired = errors.New("name is required")
)
