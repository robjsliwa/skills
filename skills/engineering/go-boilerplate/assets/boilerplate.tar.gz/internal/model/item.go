package model

import "time"

// Item is the primary domain entity.
type Item struct {
	ID          string    `json:"id"          example:"93b33649-8d10-4ca2-aeb6-8b4dc7fb37e7"`
	Name        string    `json:"name"        example:"Widget"`
	Description string    `json:"description" example:"A fine widget"`
	CreatedAt   time.Time `json:"created_at"  example:"2026-01-01T00:00:00Z"`
	UpdatedAt   time.Time `json:"updated_at"  example:"2026-01-01T00:00:00Z"`
}

// CreateItemRequest is the JSON body for POST /items.
type CreateItemRequest struct {
	// Name is the human-readable item name.
	Name string `json:"name" example:"Widget" validate:"required"`

	// Description is an optional free-form description.
	Description string `json:"description" example:"A fine widget"`
}

func (r *CreateItemRequest) Validate() error {
	if r.Name == "" {
		return ErrNameRequired
	}
	return nil
}

// UpdateItemRequest is the JSON body for PUT /items/:id.
type UpdateItemRequest struct {
	// Name is the human-readable item name.
	Name string `json:"name" example:"Widget Pro" validate:"required"`

	// Description is an optional free-form description.
	Description string `json:"description" example:"Upgraded widget"`
}

func (r *UpdateItemRequest) Validate() error {
	if r.Name == "" {
		return ErrNameRequired
	}
	return nil
}
