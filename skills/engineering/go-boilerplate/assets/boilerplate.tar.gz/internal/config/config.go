package config

import "os"

type Config struct {
	Port           string
	LogLevel       string
	ServiceName    string
	ServiceVersion string
	OTLPEndpoint   string
}

func Load() *Config {
	return &Config{
		Port:           getEnv("PORT", "8080"),
		LogLevel:       getEnv("LOG_LEVEL", "info"),
		ServiceName:    getEnv("SERVICE_NAME", "boilerplate"),
		ServiceVersion: getEnv("SERVICE_VERSION", "0.1.0"),
		OTLPEndpoint:   getEnv("OTLP_ENDPOINT", ""),
	}
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}
