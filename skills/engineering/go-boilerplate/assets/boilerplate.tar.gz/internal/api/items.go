package api

import (
	"encoding/json"
	"errors"
	"net/http"

	"github.com/go-chi/chi/v5"

	"github.com/OWNER/boilerplate/internal/model"
	"github.com/OWNER/boilerplate/internal/service"
)

type itemHandler struct {
	svc *service.ItemService
}

// list godoc
//
// @Summary      List items
// @Description  Returns all items.
// @Tags         items
// @Produce      json
// @Success      200  {array}   model.Item
// @Failure      500  {object}  errorBody  "internal error"
// @Router       /items [get]
func (h *itemHandler) list(w http.ResponseWriter, r *http.Request) {
	items, err := h.svc.List(r.Context())
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", err.Error())
		return
	}
	if items == nil {
		items = []*model.Item{}
	}
	writeJSON(w, http.StatusOK, items)
}

// get godoc
//
// @Summary      Get an item
// @Description  Returns a single item by ID.
// @Tags         items
// @Produce      json
// @Param        id   path      string  true  "Item ID"  Format(uuid)
// @Success      200  {object}  model.Item
// @Failure      404  {object}  errorBody  "item not found"
// @Failure      500  {object}  errorBody  "internal error"
// @Router       /items/{id} [get]
func (h *itemHandler) get(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	item, err := h.svc.Get(r.Context(), id)
	if err != nil {
		if errors.Is(err, model.ErrNotFound) {
			writeError(w, http.StatusNotFound, "not_found", "item not found")
			return
		}
		writeError(w, http.StatusInternalServerError, "internal_error", err.Error())
		return
	}
	writeJSON(w, http.StatusOK, item)
}

// create godoc
//
// @Summary      Create an item
// @Description  Creates a new item and returns it.
// @Tags         items
// @Accept       json
// @Produce      json
// @Param        item  body      model.CreateItemRequest  true  "Item payload"
// @Success      201   {object}  model.Item
// @Failure      400   {object}  errorBody  "malformed JSON body"
// @Failure      422   {object}  errorBody  "validation error"
// @Failure      500   {object}  errorBody  "internal error"
// @Router       /items [post]
func (h *itemHandler) create(w http.ResponseWriter, r *http.Request) {
	var req model.CreateItemRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid_body", "request body is not valid JSON")
		return
	}

	item, err := h.svc.Create(r.Context(), &req)
	if err != nil {
		if errors.Is(err, model.ErrNameRequired) {
			writeError(w, http.StatusUnprocessableEntity, "validation_error", err.Error())
			return
		}
		writeError(w, http.StatusInternalServerError, "internal_error", err.Error())
		return
	}
	writeJSON(w, http.StatusCreated, item)
}

// update godoc
//
// @Summary      Update an item
// @Description  Replaces all fields of an existing item.
// @Tags         items
// @Accept       json
// @Produce      json
// @Param        id    path      string                   true  "Item ID"  Format(uuid)
// @Param        item  body      model.UpdateItemRequest  true  "Item payload"
// @Success      200   {object}  model.Item
// @Failure      400   {object}  errorBody  "malformed JSON body"
// @Failure      404   {object}  errorBody  "item not found"
// @Failure      422   {object}  errorBody  "validation error"
// @Failure      500   {object}  errorBody  "internal error"
// @Router       /items/{id} [put]
func (h *itemHandler) update(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")

	var req model.UpdateItemRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid_body", "request body is not valid JSON")
		return
	}

	item, err := h.svc.Update(r.Context(), id, &req)
	if err != nil {
		switch {
		case errors.Is(err, model.ErrNotFound):
			writeError(w, http.StatusNotFound, "not_found", "item not found")
		case errors.Is(err, model.ErrNameRequired):
			writeError(w, http.StatusUnprocessableEntity, "validation_error", err.Error())
		default:
			writeError(w, http.StatusInternalServerError, "internal_error", err.Error())
		}
		return
	}
	writeJSON(w, http.StatusOK, item)
}

// delete godoc
//
// @Summary      Delete an item
// @Description  Permanently removes an item by ID.
// @Tags         items
// @Param        id   path  string  true  "Item ID"  Format(uuid)
// @Success      204  "no content"
// @Failure      404  {object}  errorBody  "item not found"
// @Failure      500  {object}  errorBody  "internal error"
// @Router       /items/{id} [delete]
func (h *itemHandler) delete(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	err := h.svc.Delete(r.Context(), id)
	if err != nil {
		if errors.Is(err, model.ErrNotFound) {
			writeError(w, http.StatusNotFound, "not_found", "item not found")
			return
		}
		writeError(w, http.StatusInternalServerError, "internal_error", err.Error())
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
