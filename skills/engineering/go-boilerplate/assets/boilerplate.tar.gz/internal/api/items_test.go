package api

import (
	"bytes"
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	mnoop "go.opentelemetry.io/otel/metric/noop"
	tnoop "go.opentelemetry.io/otel/trace/noop"

	"github.com/OWNER/boilerplate/internal/model"
	"github.com/OWNER/boilerplate/internal/service"
	"github.com/OWNER/boilerplate/internal/store"
)

func newTestRouter(t *testing.T) http.Handler {
	t.Helper()
	svc, err := service.NewItemService(
		store.NewMemoryStore(),
		tnoop.NewTracerProvider().Tracer("test"),
		mnoop.NewMeterProvider().Meter("test"),
	)
	if err != nil {
		t.Fatalf("NewItemService: %v", err)
	}
	return NewRouter(slog.New(slog.DiscardHandler), svc)
}

func do(t *testing.T, h http.Handler, method, path string, body io.Reader) *httptest.ResponseRecorder {
	t.Helper()
	req := httptest.NewRequest(method, path, body)
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	return rec
}

func jsonBody(t *testing.T, v any) io.Reader {
	t.Helper()
	b, err := json.Marshal(v)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	return bytes.NewReader(b)
}

func TestHealth(t *testing.T) {
	rec := do(t, newTestRouter(t), http.MethodGet, "/health", nil)
	if rec.Code != http.StatusOK {
		t.Fatalf("want 200, got %d", rec.Code)
	}
	var resp struct {
		Status string `json:"status"`
	}
	if err := json.Unmarshal(rec.Body.Bytes(), &resp); err != nil {
		t.Fatalf("decode: %v", err)
	}
	if resp.Status != "ok" {
		t.Fatalf("want status ok, got %q", resp.Status)
	}
}

func TestListEmptyReturnsArray(t *testing.T) {
	rec := do(t, newTestRouter(t), http.MethodGet, "/items", nil)
	if rec.Code != http.StatusOK {
		t.Fatalf("want 200, got %d", rec.Code)
	}
	if got := strings.TrimSpace(rec.Body.String()); got != "[]" {
		t.Fatalf("want empty JSON array, got %q", got)
	}
}

func TestCreateValidationErrors(t *testing.T) {
	tests := []struct {
		name string
		body io.Reader
		want int
	}{
		{"malformed json", strings.NewReader("{not json"), http.StatusBadRequest},
		{"empty name", jsonBody(t, model.CreateItemRequest{Name: ""}), http.StatusUnprocessableEntity},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			rec := do(t, newTestRouter(t), http.MethodPost, "/items", tt.body)
			if rec.Code != tt.want {
				t.Fatalf("want %d, got %d", tt.want, rec.Code)
			}
		})
	}
}

func TestGetMissing(t *testing.T) {
	rec := do(t, newTestRouter(t), http.MethodGet, "/items/does-not-exist", nil)
	if rec.Code != http.StatusNotFound {
		t.Fatalf("want 404, got %d", rec.Code)
	}
}

func TestItemLifecycle(t *testing.T) {
	router := newTestRouter(t)

	rec := do(t, router, http.MethodPost, "/items", jsonBody(t, model.CreateItemRequest{Name: "Widget"}))
	if rec.Code != http.StatusCreated {
		t.Fatalf("create: want 201, got %d", rec.Code)
	}
	var created model.Item
	if err := json.Unmarshal(rec.Body.Bytes(), &created); err != nil {
		t.Fatalf("decode created: %v", err)
	}
	if created.ID == "" {
		t.Fatal("create: expected a generated ID")
	}

	rec = do(t, router, http.MethodGet, "/items/"+created.ID, nil)
	if rec.Code != http.StatusOK {
		t.Fatalf("get: want 200, got %d", rec.Code)
	}

	rec = do(t, router, http.MethodPut, "/items/"+created.ID, jsonBody(t, model.UpdateItemRequest{Name: "Widget Pro"}))
	if rec.Code != http.StatusOK {
		t.Fatalf("update: want 200, got %d", rec.Code)
	}

	rec = do(t, router, http.MethodDelete, "/items/"+created.ID, nil)
	if rec.Code != http.StatusNoContent {
		t.Fatalf("delete: want 204, got %d", rec.Code)
	}

	rec = do(t, router, http.MethodGet, "/items/"+created.ID, nil)
	if rec.Code != http.StatusNotFound {
		t.Fatalf("get after delete: want 404, got %d", rec.Code)
	}
}
