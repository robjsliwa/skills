package api

import (
	"encoding/json"
	"log/slog"
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"
	chimw "github.com/go-chi/chi/v5/middleware"
	httpswagger "github.com/swaggo/http-swagger/v2"
	"go.opentelemetry.io/contrib/instrumentation/net/http/otelhttp"

	"github.com/OWNER/boilerplate/internal/middleware"
	"github.com/OWNER/boilerplate/internal/service"
)

type healthResponse struct {
	Status string `json:"status" example:"ok"`
	Time   string `json:"time"   example:"2026-01-01T00:00:00Z"`
}

func NewRouter(logger *slog.Logger, itemSvc *service.ItemService) http.Handler {
	r := chi.NewRouter()

	r.Use(chimw.RequestID)
	r.Use(chimw.RealIP)
	r.Use(middleware.Recovery(logger))
	r.Use(middleware.Logger(logger))

	r.Get("/health", health)
	r.Get("/docs/*", httpswagger.Handler(
		httpswagger.URL("/docs/doc.json"),
	))

	items := &itemHandler{svc: itemSvc}
	r.Route("/items", func(r chi.Router) {
		r.Get("/", items.list)
		r.Post("/", items.create)
		r.Get("/{id}", items.get)
		r.Put("/{id}", items.update)
		r.Delete("/{id}", items.delete)
	})

	return otelhttp.NewHandler(r, "http.server")
}

// health godoc
//
// @Summary      Health check
// @Description  Returns service liveness status.
// @Tags         health
// @Produce      json
// @Success      200  {object}  healthResponse
// @Router       /health [get]
func health(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(healthResponse{
		Status: "ok",
		Time:   time.Now().UTC().Format(time.RFC3339),
	})
}
