package api

import (
	"encoding/json"
	"net/http"
)

// errorBody is the JSON shape returned on all error responses.
type errorBody struct {
	Code    string `json:"code"    example:"not_found"`
	Message string `json:"message" example:"item not found"`
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func writeError(w http.ResponseWriter, status int, code, message string) {
	writeJSON(w, status, errorBody{Code: code, Message: message})
}
