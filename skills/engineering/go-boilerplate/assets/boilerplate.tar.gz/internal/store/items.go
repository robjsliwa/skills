package store

import (
	"context"
	"sync"

	"github.com/OWNER/boilerplate/internal/model"
)

type ItemStore interface {
	List(ctx context.Context) ([]*model.Item, error)
	Get(ctx context.Context, id string) (*model.Item, error)
	Create(ctx context.Context, item *model.Item) error
	Update(ctx context.Context, item *model.Item) error
	Delete(ctx context.Context, id string) error
}

type memoryStore struct {
	mu    sync.RWMutex
	items map[string]*model.Item
}

func NewMemoryStore() ItemStore {
	return &memoryStore{
		items: make(map[string]*model.Item),
	}
}

func (s *memoryStore) List(_ context.Context) ([]*model.Item, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	result := make([]*model.Item, 0, len(s.items))
	for _, item := range s.items {
		copy := *item
		result = append(result, &copy)
	}
	return result, nil
}

func (s *memoryStore) Get(_ context.Context, id string) (*model.Item, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	item, ok := s.items[id]
	if !ok {
		return nil, model.ErrNotFound
	}
	copy := *item
	return &copy, nil
}

func (s *memoryStore) Create(_ context.Context, item *model.Item) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	copy := *item
	s.items[item.ID] = &copy
	return nil
}

func (s *memoryStore) Update(_ context.Context, item *model.Item) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if _, ok := s.items[item.ID]; !ok {
		return model.ErrNotFound
	}
	copy := *item
	s.items[item.ID] = &copy
	return nil
}

func (s *memoryStore) Delete(_ context.Context, id string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if _, ok := s.items[id]; !ok {
		return model.ErrNotFound
	}
	delete(s.items, id)
	return nil
}
