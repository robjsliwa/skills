package store

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/OWNER/boilerplate/internal/model"
)

func newItem(id, name string) *model.Item {
	now := time.Now().UTC()
	return &model.Item{ID: id, Name: name, CreatedAt: now, UpdatedAt: now}
}

func TestMemoryStore_CRUD(t *testing.T) {
	ctx := context.Background()
	s := NewMemoryStore()

	items, err := s.List(ctx)
	if err != nil {
		t.Fatalf("List on empty store: %v", err)
	}
	if len(items) != 0 {
		t.Fatalf("want 0 items, got %d", len(items))
	}

	if err := s.Create(ctx, newItem("id-1", "Widget")); err != nil {
		t.Fatalf("Create: %v", err)
	}

	got, err := s.Get(ctx, "id-1")
	if err != nil {
		t.Fatalf("Get: %v", err)
	}
	if got.Name != "Widget" {
		t.Fatalf("want name Widget, got %q", got.Name)
	}

	if err := s.Update(ctx, newItem("id-1", "Widget Pro")); err != nil {
		t.Fatalf("Update: %v", err)
	}
	got, err = s.Get(ctx, "id-1")
	if err != nil {
		t.Fatalf("Get after update: %v", err)
	}
	if got.Name != "Widget Pro" {
		t.Fatalf("want name Widget Pro, got %q", got.Name)
	}

	if err := s.Delete(ctx, "id-1"); err != nil {
		t.Fatalf("Delete: %v", err)
	}
	if _, err := s.Get(ctx, "id-1"); !errors.Is(err, model.ErrNotFound) {
		t.Fatalf("want ErrNotFound after delete, got %v", err)
	}
}

func TestMemoryStore_NotFound(t *testing.T) {
	ctx := context.Background()
	s := NewMemoryStore()

	tests := []struct {
		name string
		op   func() error
	}{
		{"get", func() error { _, err := s.Get(ctx, "missing"); return err }},
		{"update", func() error { return s.Update(ctx, newItem("missing", "x")) }},
		{"delete", func() error { return s.Delete(ctx, "missing") }},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := tt.op(); !errors.Is(err, model.ErrNotFound) {
				t.Fatalf("want ErrNotFound, got %v", err)
			}
		})
	}
}

// The store must hand out copies so callers cannot mutate stored state by
// holding on to a returned pointer.
func TestMemoryStore_ReturnsCopies(t *testing.T) {
	ctx := context.Background()
	s := NewMemoryStore()
	if err := s.Create(ctx, newItem("id-1", "Widget")); err != nil {
		t.Fatalf("Create: %v", err)
	}

	got, err := s.Get(ctx, "id-1")
	if err != nil {
		t.Fatalf("Get: %v", err)
	}
	got.Name = "Mutated"

	again, err := s.Get(ctx, "id-1")
	if err != nil {
		t.Fatalf("Get again: %v", err)
	}
	if again.Name != "Widget" {
		t.Fatalf("store mutated through returned pointer: got %q", again.Name)
	}
}
