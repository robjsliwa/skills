package service

import (
	"context"
	"errors"
	"testing"

	mnoop "go.opentelemetry.io/otel/metric/noop"
	tnoop "go.opentelemetry.io/otel/trace/noop"

	"github.com/OWNER/boilerplate/internal/model"
	"github.com/OWNER/boilerplate/internal/store"
)

func newTestService(t *testing.T) *ItemService {
	t.Helper()
	svc, err := NewItemService(
		store.NewMemoryStore(),
		tnoop.NewTracerProvider().Tracer("test"),
		mnoop.NewMeterProvider().Meter("test"),
	)
	if err != nil {
		t.Fatalf("NewItemService: %v", err)
	}
	return svc
}

func TestItemService_CreateValidation(t *testing.T) {
	svc := newTestService(t)
	_, err := svc.Create(context.Background(), &model.CreateItemRequest{Name: ""})
	if !errors.Is(err, model.ErrNameRequired) {
		t.Fatalf("want ErrNameRequired, got %v", err)
	}
}

func TestItemService_CreateGetUpdateDelete(t *testing.T) {
	ctx := context.Background()
	svc := newTestService(t)

	created, err := svc.Create(ctx, &model.CreateItemRequest{Name: "Widget", Description: "d"})
	if err != nil {
		t.Fatalf("Create: %v", err)
	}
	if created.ID == "" {
		t.Fatal("expected a generated ID")
	}

	got, err := svc.Get(ctx, created.ID)
	if err != nil {
		t.Fatalf("Get: %v", err)
	}
	if got.Name != "Widget" {
		t.Fatalf("want name Widget, got %q", got.Name)
	}

	updated, err := svc.Update(ctx, created.ID, &model.UpdateItemRequest{Name: "Widget Pro"})
	if err != nil {
		t.Fatalf("Update: %v", err)
	}
	if updated.Name != "Widget Pro" {
		t.Fatalf("want name Widget Pro, got %q", updated.Name)
	}

	if err := svc.Delete(ctx, created.ID); err != nil {
		t.Fatalf("Delete: %v", err)
	}
	if _, err := svc.Get(ctx, created.ID); !errors.Is(err, model.ErrNotFound) {
		t.Fatalf("want ErrNotFound after delete, got %v", err)
	}
}

func TestItemService_NotFound(t *testing.T) {
	ctx := context.Background()
	svc := newTestService(t)

	if _, err := svc.Get(ctx, "missing"); !errors.Is(err, model.ErrNotFound) {
		t.Fatalf("Get: want ErrNotFound, got %v", err)
	}
	if _, err := svc.Update(ctx, "missing", &model.UpdateItemRequest{Name: "x"}); !errors.Is(err, model.ErrNotFound) {
		t.Fatalf("Update: want ErrNotFound, got %v", err)
	}
	if err := svc.Delete(ctx, "missing"); !errors.Is(err, model.ErrNotFound) {
		t.Fatalf("Delete: want ErrNotFound, got %v", err)
	}
}
