package service

import (
	"context"
	"crypto/rand"
	"fmt"
	"time"

	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/metric"

	"github.com/OWNER/boilerplate/internal/model"
	"github.com/OWNER/boilerplate/internal/store"
)

type ItemService struct {
	store   store.ItemStore
	ops     metric.Int64Counter
	tracer  interface{ Start(ctx context.Context, spanName string, opts ...interface{}) (context.Context, interface{}) }
}

func NewItemService(s store.ItemStore) (*ItemService, error) {
	meter := otel.GetMeterProvider().Meter("boilerplate")
	ops, err := meter.Int64Counter("items.operations",
		metric.WithDescription("Total number of item store operations"),
	)
	if err != nil {
		return nil, err
	}
	return &ItemService{store: s, ops: ops}, nil
}

func (svc *ItemService) List(ctx context.Context) ([]*model.Item, error) {
	tr := otel.Tracer("boilerplate")
	ctx, span := tr.Start(ctx, "items.List")
	defer span.End()

	items, err := svc.store.List(ctx)
	svc.ops.Add(ctx, 1, metric.WithAttributes(attribute.String("op", "list"), attribute.Bool("error", err != nil)))
	return items, err
}

func (svc *ItemService) Get(ctx context.Context, id string) (*model.Item, error) {
	tr := otel.Tracer("boilerplate")
	ctx, span := tr.Start(ctx, "items.Get")
	defer span.End()

	item, err := svc.store.Get(ctx, id)
	svc.ops.Add(ctx, 1, metric.WithAttributes(attribute.String("op", "get"), attribute.Bool("error", err != nil)))
	return item, err
}

func (svc *ItemService) Create(ctx context.Context, req *model.CreateItemRequest) (*model.Item, error) {
	tr := otel.Tracer("boilerplate")
	ctx, span := tr.Start(ctx, "items.Create")
	defer span.End()

	if err := req.Validate(); err != nil {
		return nil, err
	}

	now := time.Now().UTC()
	item := &model.Item{
		ID:          generateID(),
		Name:        req.Name,
		Description: req.Description,
		CreatedAt:   now,
		UpdatedAt:   now,
	}

	err := svc.store.Create(ctx, item)
	svc.ops.Add(ctx, 1, metric.WithAttributes(attribute.String("op", "create"), attribute.Bool("error", err != nil)))
	if err != nil {
		return nil, err
	}
	return item, nil
}

func (svc *ItemService) Update(ctx context.Context, id string, req *model.UpdateItemRequest) (*model.Item, error) {
	tr := otel.Tracer("boilerplate")
	ctx, span := tr.Start(ctx, "items.Update")
	defer span.End()

	if err := req.Validate(); err != nil {
		return nil, err
	}

	existing, err := svc.store.Get(ctx, id)
	if err != nil {
		return nil, err
	}

	existing.Name = req.Name
	existing.Description = req.Description
	existing.UpdatedAt = time.Now().UTC()

	err = svc.store.Update(ctx, existing)
	svc.ops.Add(ctx, 1, metric.WithAttributes(attribute.String("op", "update"), attribute.Bool("error", err != nil)))
	if err != nil {
		return nil, err
	}
	return existing, nil
}

func (svc *ItemService) Delete(ctx context.Context, id string) error {
	tr := otel.Tracer("boilerplate")
	ctx, span := tr.Start(ctx, "items.Delete")
	defer span.End()

	err := svc.store.Delete(ctx, id)
	svc.ops.Add(ctx, 1, metric.WithAttributes(attribute.String("op", "delete"), attribute.Bool("error", err != nil)))
	return err
}

func generateID() string {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		panic(fmt.Sprintf("crypto/rand failed: %v", err))
	}
	b[6] = (b[6] & 0x0f) | 0x40 // version 4
	b[8] = (b[8] & 0x3f) | 0x80 // variant bits
	return fmt.Sprintf("%08x-%04x-%04x-%04x-%012x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:])
}
